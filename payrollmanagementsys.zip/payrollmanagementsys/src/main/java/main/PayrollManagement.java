package main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;
import entity.Payroll;
import entity.Tax;

public class PayrollManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Connection connection = null;
        try {
            // Establish database connection
            String connectionString = "jdbc:mysql://localhost:3306/payrollmanagementsystem";
            String username = "root";
            String password = "VijiViji1515";
            connection = DriverManager.getConnection(connectionString, username, password);

            while (true) {
                System.out.println("Menu:");
                System.out.println("1. Add Employee");
                System.out.println("2. Generate Payroll");
                System.out.println("3. Calculate Tax");            
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        addEmployee(connection, scanner);
                        break;
                    case 2:
                        generatePayroll(connection);
                        break;
                    case 3:
                        calculateTax(connection);
                        break;
                    case 4:
                        addFinancialRecord(connection);
                        break;
                    case 5:
                        System.out.println("Exiting application...");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please enter a valid option.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Close the database connection
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    private static void addEmployee(Connection connection, Scanner scanner) {
        // Placeholder implementation for adding an employee
        System.out.println("Enter employee details:");
        System.out.print("First Name: ");
        String firstName = scanner.next();
        System.out.print("Last Name: ");
        String lastName = scanner.next();
        // Add other employee details input here

        // Execute SQL query to insert employee data into the database
        String sql = "INSERT INTO employee (employeeid, firstname, lastname, dateofbirth, gender, email, phonenumber, address, position, joiningdate, terminationdate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            // Generate employee ID
            int employeeId = generateEmployeeId(connection);

            statement.setInt(1, employeeId);
            statement.setString(2, firstName);
            statement.setString(3, lastName);
            // Set other employee details
            // For simplicity, I'm assuming the date fields are null for now
            statement.setNull(4, java.sql.Types.DATE); // dateofbirth
            statement.setNull(5, java.sql.Types.CHAR); // gender
            statement.setNull(6, java.sql.Types.VARCHAR); // email
            statement.setNull(7, java.sql.Types.VARCHAR); // phonenumber
            statement.setNull(8, java.sql.Types.VARCHAR); // address
            statement.setNull(9, java.sql.Types.VARCHAR); // position
            statement.setNull(10, java.sql.Types.DATE); // joiningdate
            statement.setNull(11, java.sql.Types.DATE); // terminationdate

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee added successfully.");
            } else {
                System.out.println("Failed to add employee.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error: Failed to add employee.");
        }
    }

    private static int generateEmployeeId(Connection connection) throws SQLException {
        int employeeId = 0;
        String sql = "SELECT MAX(employeeid) FROM employee";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                employeeId = resultSet.getInt(1) + 1;
            } else {
                employeeId = 1;
            }
        }
        return employeeId;
    }


  

  
    private static final String PAYROLL_QUERY = "SELECT * FROM payroll";
    public static void generatePayroll(Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(PAYROLL_QUERY);
             ResultSet resultSet = statement.executeQuery()) {

            System.out.println("Generating Payroll:");
            System.out.println("---------------------");

            while (resultSet.next()) {
                int payrollID = resultSet.getInt("payrollid");
                int employeeID = resultSet.getInt("employeeid");
                LocalDate payPeriodStartDate = resultSet.getDate("payperiodstartdate").toLocalDate();
                LocalDate payPeriodEndDate = resultSet.getDate("payperiodenddate").toLocalDate();
                double basicSalary = resultSet.getDouble("basicsalary");
                double overtimePay = resultSet.getDouble("overtimepay");
                double deductions = resultSet.getDouble("deductions");

                // Calculate net salary
                double netSalary = basicSalary + overtimePay - deductions;

                // Create Payroll object
                Payroll payroll = new Payroll(payrollID, employeeID, payPeriodStartDate, payPeriodEndDate,
                        basicSalary, overtimePay, deductions, netSalary);

                // Print payroll details
                System.out.println(payroll);
                System.out.println("---------------------");
            }

            System.out.println("Payroll generation completed.");
        }
    }


 
    
    private static final String TAX_QUERY = "SELECT * FROM tax";
    public static void calculateTax(Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(TAX_QUERY);
             ResultSet resultSet = statement.executeQuery()) {

            System.out.println("Calculating Tax:");
            System.out.println("---------------------");

            while (resultSet.next()) {
                int taxID = resultSet.getInt("taxID");
                int employeeID = resultSet.getInt("employeeID");
                int taxYear = resultSet.getInt("taxYear");
                double taxableIncome = resultSet.getDouble("taxableIncome");
                double taxAmount = resultSet.getDouble("taxAmount");

                // Create Tax object
                Tax tax = new Tax(taxID, employeeID, taxYear, taxableIncome, taxAmount);

                // Print tax details
                System.out.println(tax);
                System.out.println("---------------------");
            }

            System.out.println("Tax calculation completed.");
        }
    }
    
    
    private static final String INSERT_FINANCIAL_RECORD_QUERY = "INSERT INTO financial_record (employeeID, recordDate, description, amount, recordType) VALUES (?, ?, ?, ?, ?)";
    public static void addFinancialRecord(Connection connection) throws SQLException {
        // Get user input for financial record details
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter financial record details:");
        System.out.print("Employee ID: ");
        int employeeID = scanner.nextInt();
        System.out.print("Amount: ");
        double amount = scanner.nextDouble();
        System.out.print("Record Type: ");
        String recordType = scanner.next();

        // Insert financial record into the database
        try (PreparedStatement statement = connection.prepareStatement(INSERT_FINANCIAL_RECORD_QUERY)) {
            statement.setInt(1, employeeID);
            String recordDate = null;
			statement.setDate(2, java.sql.Date.valueOf(recordDate));
            String description = null;
			statement.setString(3, description);
            statement.setDouble(4, amount);
            statement.setString(5, recordType);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Financial record added successfully.");
            } else {
                System.out.println("Failed to add financial record.");
            }
        }
    }  
}