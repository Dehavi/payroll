/**
 * 
 */
/**
 * 
 */
module payrollmanagementsystem {
	requires java.sql;
}